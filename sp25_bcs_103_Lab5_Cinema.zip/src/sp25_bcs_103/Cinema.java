package sp25_bcs_103;

public class Cinema {
    private String name;
    private Screen[] screens;
    private int size;
    public Cinema(String name, int initialCapacity) {
        this.name = name;
        this.screens = new Screen[Math.max(1, initialCapacity)];
        this.size = 0;
    }
    public void addScreen(Screen s) {
        if (size >= screens.length) {
            Screen[] bigger = new Screen[screens.length * 2];
            for (int i = 0; i < screens.length; i++) bigger[i] = screens[i];
            screens = bigger;
        }
        screens[size++] = s;
    }
    public void addScreen(String screenName, int[] rowLengths) {
        addScreen(new Screen(screenName, rowLengths));
    }
    public Screen findScreen(String screenName) {
        for (int i = 0; i < size; i++) {
            if (screens[i] != null && screens[i].getScreenName().equals(screenName)) return screens[i];
        }
        return null;
    }
    public Screen findScreenByIndex(int idxZeroBased) {
        if (idxZeroBased < 0 || idxZeroBased >= size) return null;
        return screens[idxZeroBased];
    }
    public boolean book(String screenName, String seatId) {
        Screen s = findScreen(screenName);
        if (s == null) return false;
        return s.book(seatId);
    }
    public boolean cancel(String screenName, String seatId) {
        Screen s = findScreen(screenName);
        if (s == null) return false;
        return s.cancel(seatId);
    }
    public int getTotalSeats() {
        int total = 0;
        for (int i = 0; i < size; i++) total += screens[i].getTotalSeatCount();
        return total;
    }
    public int getAvailableSeats() {
        int total = 0;
        for (int i = 0; i < size; i++) total += screens[i].getAvailableSeatCount();
        return total;
    }
    public int getAvailableSeats(SeatType type) {
        int total = 0;
        for (int i = 0; i < size; i++) total += screens[i].getAvailableSeatCount(type);
        return total;
    }
    public void displayLayouts() {
        System.out.println("Cinema: " + name);
        for (int i = 0; i < size; i++) {
        System.out.println("  Screen #" + (i+1) + " : " + screens[i].getScreenName());
        screens[i].displayLayout();
        System.out.println();
        }
    }
    public String getName() {
        return name;
    }
    public String toString() {
        return String.format("%s (screens=%d, totalSeats=%d, available=%d)",
                name, size, getTotalSeats(), getAvailableSeats());
    }
    public int getScreenCount() {
        return size;
    }
    public Screen[] getScreens() {
        Screen[] copy = new Screen[size];
        for (int i = 0; i < size; i++) copy[i] = screens[i];
        return copy;
    }
}
