package sp25_bcs_103;

public class CityCinema {
    private String cityName;
    private Cinema[] cinemas;
    private int size;
    public CityCinema(String cityName, int initialCapacity) {
        this.cityName = cityName;
        this.cinemas = new Cinema[Math.max(1, initialCapacity)];
        this.size = 0;
    }
    public void addCinema(Cinema c) {
        if (size >= cinemas.length) {
        Cinema[] bigger = new Cinema[cinemas.length * 2];
        for (int i = 0; i < cinemas.length; i++) bigger[i] = cinemas[i];
        cinemas = bigger;
        }
        cinemas[size++] = c;
    }
    public Cinema findCinema(String name) {
        for (int i = 0; i < size; i++) {
            if (cinemas[i] != null && cinemas[i].getName().equals(name)) return cinemas[i];
        }
        return null;
    }
    public boolean removeCinema(String name) {
        for (int i = 0; i < size; i++) {			
        if (cinemas[i] != null && cinemas[i].getName().equals(name)) {
        for (int j = i; j < size - 1; j++) cinemas[j] = cinemas[j+1];
        cinemas[size - 1] = null;
        size--;
        return true;
            }
        }
        return false;
    }
    public boolean book(String cinemaName, String screenName, String seatId) {
        Cinema c = findCinema(cinemaName);
        if (c == null) return false;
        return c.book(screenName, seatId);
    }
    public boolean cancel(String cinemaName, String screenName, String seatId) {
        Cinema c = findCinema(cinemaName);
        if (c == null) return false;
        return c.cancel(screenName, seatId);
    }
    public int getTotalSeats() {
        int t = 0;
        for (int i = 0; i < size; i++) t += cinemas[i].getTotalSeats();
        return t;
    }
    public int getAvailableSeats() {
        int t = 0;
        for (int i = 0; i < size; i++) t += cinemas[i].getAvailableSeats();
        return t;
    }
    public String firstAvailableVIP() {
        for (int i = 0; i < size; i++) {
        Cinema c = cinemas[i];
        Screen[] screens = c.getScreens();
        for (int sIndex = 0; sIndex < screens.length; sIndex++) {
        Screen s = screens[sIndex];
        Seat seat = s.findFirstAvailable(SeatType.VIP);
        if (seat != null) {
        return String.format("%s > %s > %s (%s, %.2f PKR)",
        c.getName(), s.getScreenName(), seat.getId(), seat.getSeatType().name(), seat.getPrice());
                }
            }
        }
        return null;
    }
    public void displayCityLayouts() {
        System.out.println("City: " + cityName);
        for (int i = 0; i < size; i++) {
            System.out.println(cinemas[i].toString());
            cinemas[i].displayLayouts();
        }
    }
    public static CityCinema preloadExampleCity(String cityName) {
        CityCinema city = new CityCinema(cityName, 2);
        Cinema c1 = new Cinema(cityName + " - CineOne", 2);
        c1.addScreen(new Screen("Screen-A", Screen.buildDefaultRowLengths(5)));
        c1.addScreen(new Screen("Screen-B", Screen.buildDefaultRowLengths(5)));
        Cinema c2 = new Cinema(cityName + " - CineTwo", 2);
        c2.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        c2.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        city.addCinema(c1);
        city.addCinema(c2);
        return city;
    }
}
