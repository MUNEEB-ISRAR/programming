package sp25_bcs_103;

public class SeatDemo {
    public static void main(String[] args) {
        System.out.println("=== Seat Demo ===");
        Seat s1 = new Seat(1, 1, SeatType.REGULAR, 500.0);
        Seat s2 = new Seat(1, 2, SeatType.PREMIUM, 750.0);
        Seat s3 = new Seat(5, 5, SeatType.RECLINER, 1200.0);
        System.out.println("Initial:");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println("\nBooking s1 and s2:");
        System.out.println("book s1: " + s1.bookSeat());
        System.out.println("book s2: " + s2.bookSeat());
        System.out.println(s1);
        System.out.println(s2);
        System.out.println("\nAttempt double booking s1:");
        System.out.println("book s1 again: " + s1.bookSeat());
        System.out.println("\nCancel s2:");
        System.out.println("cancel s2: " + s2.cancelBooking());
        System.out.println(s2);
        System.out.println("\nChange s3 price:");
        s3.setPrice(1300.0);
        System.out.println(s3);
        System.out.println("=== End Seat Demo ===");
    }
}
