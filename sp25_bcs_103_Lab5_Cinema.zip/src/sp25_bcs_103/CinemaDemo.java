package sp25_bcs_103;

public class CinemaDemo {
    public static void main(String[] args) {
        System.out.println("=== Cinema Demo (preloaded cities) ===");
        CityCinema karachi = new CityCinema("Karachi", 3);
        CityCinema lahore = new CityCinema("Lahore", 3);
        CityCinema islamabad = new CityCinema("Islamabad", 2);
        Cinema atrium = new Cinema("Atrium Saddar", 2);
        atrium.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        atrium.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        Cinema nueplex = new Cinema("Nueplex DHA", 2);
        nueplex.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        nueplex.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        karachi.addCinema(atrium);
        karachi.addCinema(nueplex);
        Cinema cineTown = new Cinema("CineStar Township", 2);
        cineTown.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        cineTown.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        Cinema cineGulberg = new Cinema("CineStar Gulberg", 2);
        cineGulberg.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        cineGulberg.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        lahore.addCinema(cineTown);
        lahore.addCinema(cineGulberg);
        Cinema centaurus = new Cinema("Centaurus Megaplex", 2);
        centaurus.addScreen(new Screen("Screen-1", Screen.buildDefaultRowLengths(5)));
        centaurus.addScreen(new Screen("Screen-2", Screen.buildDefaultRowLengths(5)));
        islamabad.addCinema(centaurus);
        System.out.println("\n--- Karachi layouts ---");
        karachi.displayCityLayouts();
        System.out.println("\n--- Lahore layouts ---");
        lahore.displayCityLayouts();
        System.out.println("\n--- Islamabad layouts ---");
        islamabad.displayCityLayouts();
        System.out.println("\n--- Booking workflow ---");
        String cinemaName = "Atrium Saddar";
        String screenName = "Screen-1";
        String seatId = "3-007";
        System.out.println("Attempt booking " + seatId + " at " + cinemaName + " > " + screenName);
        boolean booked = karachi.book(cinemaName, screenName, seatId);
        System.out.print("First booking attempt: ");
	if (booked) {
    	System.out.println("SUCCESS");
	} else {
    	System.out.println("FAIL");
	}
	System.out.println("Attempt booking same seat again (should be rejected):");
	boolean bookedAgain = karachi.book(cinemaName, screenName, seatId);
	System.out.print("Second booking attempt: ");
	if (bookedAgain) {
    	System.out.println("SUCCESS (ERROR)");
	} else {
    	System.out.println("REJECTED (expected)");
	}
	System.out.println("Cancel the booking:");
	boolean cancelled = karachi.cancel(cinemaName, screenName, seatId);
	System.out.print("Cancellation: ");
	if (cancelled) {
    	System.out.println("SUCCESS");
	} else {
    	System.out.println("FAIL");
	}
	System.out.println("\nConfirm layouts after booking/cancel:");
	karachi.displayCityLayouts();
	System.out.println("\nSearch: first available VIP seat in Lahore:");
	String firstVip = lahore.firstAvailableVIP();
	if (firstVip != null) {
    	System.out.println("Found: " + firstVip);
	} else {
    	System.out.println("No VIP seats available.");
	}
	System.out.println("\n=== End Cinema Demo ===");
		}
	}
