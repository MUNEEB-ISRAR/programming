package sp25_bcs_103;

public enum SeatType {
    REGULAR,
    PREMIUM,
    VIP,
    RECLINER
}
