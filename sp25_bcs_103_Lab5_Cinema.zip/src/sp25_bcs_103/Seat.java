package sp25_bcs_103;

public class Seat {
    private SeatType seatType;
    private double price;
    private String id;
    private boolean isAvailable;
    public Seat() {
        this.id = "0-000";
        this.seatType = SeatType.REGULAR;
        this.price = 0.0;
        this.isAvailable = true;
    }
    public Seat(int row, int col, SeatType type, double price) {
        this.id = formatId(row, col);
        this.seatType = type;
        this.price = price;
        this.isAvailable = true;
    }
    private String formatId(int row, int col) {
    return row + "-" + String.format("%03d", col);
    }
    public boolean bookSeat() {
        if (!isAvailable) return false;
        isAvailable = false;
        return true;
    }
    public boolean cancelBooking() {
        if (isAvailable) return false;
        isAvailable = true;
        return true;
    }
    public String getId() {
        return id;
    }
    public SeatType getSeatType() {
        return seatType;
    }
    public boolean isAvailable() {
        return isAvailable;
    }
    public double getPrice() {
        return price;
    }
    public void setSeatType(SeatType type) {
        this.seatType = type;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    @Override
    public String toString() {
    return String.format("%s (%s, %.2f PKR) %s",
    id, seatType.name(), price, (isAvailable ? "[available]" : "[booked]"));
    }
}
