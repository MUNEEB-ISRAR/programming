package sp25_bcs_103;

public class Screen {
    private static final double PRICE_REGULAR = 500.0;
    private static final double PRICE_PREMIUM = 750.0;
    private static final double PRICE_VIP = 1000.0;
    private static final double PRICE_RECLINER = 1200.0;
    private static final int DEFAULT_NUM_ROWS = 5;
    private Seat[][] seats;
    private String screenName;
    public Screen() {
        this("Unnamed Screen", buildDefaultRowLengths(DEFAULT_NUM_ROWS));
    }
    public Screen(String name, int[] rowLengths) {
        this.screenName = name;
        materializeSeats(rowLengths);
    }
    private void materializeSeats(int[] rowLengths) {
        seats = new Seat[rowLengths.length][];
        for (int r = 0; r < rowLengths.length; r++) {
        seats[r] = new Seat[rowLengths[r]];
        for (int c = 0; c < rowLengths[r]; c++) {
        SeatType type = computeTypeForRow(r, rowLengths.length);
        double price = priceFor(type);
        seats[r][c] = new Seat(r + 1, c + 1, type, price);
            }
        }
    }
    private SeatType computeTypeForRow(int rowIndexZeroBased, int totalRows) {
        if (rowIndexZeroBased == totalRows - 1) return SeatType.RECLINER; 
        if (rowIndexZeroBased == totalRows - 2) return SeatType.VIP;
        int frontLimit = Math.max(1, totalRows / 2 - 1);
        if (rowIndexZeroBased <= frontLimit - 1) return SeatType.REGULAR;
        return SeatType.PREMIUM;
    }
    public double priceFor(SeatType type) {
        switch (type) {
            case PREMIUM: return PRICE_PREMIUM;
            case VIP: return PRICE_VIP;
            case RECLINER: return PRICE_RECLINER;
            case REGULAR:
            default:
            return PRICE_REGULAR;
        }
    }
    public Seat getSeat(int row, int col) {
        if (!checkBounds(row, col)) return null;
        return seats[row - 1][col - 1];
    }
    public Seat getSeat(String id) {
        if (id == null) return null;
        String[] parts = id.split("-");
        if (parts.length != 2) return null;
        try {
            int row = Integer.parseInt(parts[0]);
            int col = Integer.parseInt(parts[1]);
            return getSeat(row, col);
        } catch (NumberFormatException e) {
            return null;
        }
    }
    public boolean book(String id) {
        Seat s = getSeat(id);
        if (s == null) return false;
        return s.bookSeat();
    }
    public boolean book(int row, int col) {
        Seat s = getSeat(row, col);
        if (s == null) return false;
        return s.bookSeat();
    }
    public boolean cancel(String id) {
        Seat s = getSeat(id);
        if (s == null) return false;
        return s.cancelBooking();
    }
    public boolean cancel(int row, int col) {
        Seat s = getSeat(row, col);
        if (s == null) return false;
        return s.cancelBooking();
    }
    public int getTotalSeatCount() {
        int total = 0;
        for (int r = 0; r < seats.length; r++) total += seats[r].length;
        return total;
    }
    public int getAvailableSeatCount() {
        int count = 0;
        for (int r = 0; r < seats.length; r++) {
        for (int c = 0; c < seats[r].length; c++) {
        if (seats[r][c].isAvailable()) count++;
            }
        }
        return count;
    }
    public int getAvailableSeatCount(SeatType type) {
        int count = 0;
        for (int r = 0; r < seats.length; r++) {
            for (int c = 0; c < seats[r].length; c++) {
                if (seats[r][c].isAvailable() && seats[r][c].getSeatType() == type) count++;
            }
        }
        return count;
    }
    public Seat[] listAvailable(SeatType type) {
        int matches = 0;
        for (int r = 0; r < seats.length; r++) {
        for (int c = 0; c < seats[r].length; c++) {
        if (seats[r][c].isAvailable() && seats[r][c].getSeatType() == type) matches++;
            }
        }
        Seat[] result = new Seat[matches];
        int idx = 0;
        for (int r = 0; r < seats.length; r++) {
        for (int c = 0; c < seats[r].length; c++) {
        if (seats[r][c].isAvailable() && seats[r][c].getSeatType() == type) {
        result[idx++] = seats[r][c];
                }
            }
        }
        return result;
    }
    public Seat findFirstAvailable(SeatType type) {
        for (int r = 0; r < seats.length; r++) {
        for (int c = 0; c < seats[r].length; c++) {
        Seat s = seats[r][c];
        if (s.isAvailable() && s.getSeatType() == type) return s;
            }
        }
        return null;
    }
    public void displayLayout() {
        System.out.println("Layout for screen: " + screenName);
        for (int r = 0; r < seats.length; r++) {
        System.out.printf("Row %d: ", r + 1);
        for (int c = 0; c < seats[r].length; c++) {
        if (seats[r][c].isAvailable()) {
        System.out.print("A");
	} else {
        System.out.print("X");
	}
	if (c < seats[r].length - 1) {
        System.out.print(" ");
}
        }
            System.out.println();
        }
    }
    public void displayVerbose() {
        System.out.println("Detailed seat list for screen: " + screenName);
        for (int r = 0; r < seats.length; r++) {
        for (int c = 0; c < seats[r].length; c++) {
        System.out.println(seats[r][c].toString());
            }
        }
    }
    public int getRowCount() {
        return seats.length;
    }
    public int getRowLength(int rowOneBased) {
        if (rowOneBased < 1 || rowOneBased > seats.length) return 0;
        return seats[rowOneBased - 1].length;
    }
    public String getScreenName() {
        return screenName;
    }
    public static int[] buildDefaultRowLengths(int rows) {
        int[] arr = new int[rows];
        for (int i = 0; i < rows; i++) {
        arr[i] = 10 + i;
        }
        return arr;
    }
    public void setRowType(int rowOneBased, SeatType type, Double customPrice) {
        if (rowOneBased < 1 || rowOneBased > seats.length) return;
        int r = rowOneBased - 1;
        double priceToSet;
	if (customPrice != null) {
        priceToSet = customPrice;
	} else {
        priceToSet = priceFor(type);
    }
        for (int c = 0; c < seats[r].length; c++) {
        seats[r][c].setSeatType(type);
        seats[r][c].setPrice(priceToSet);
        }
    }
    public SeatType seatTypeFor(int row, int col) {
        Seat s = getSeat(row, col);
        if (s == null) return null;
        return s.getSeatType();
    }
    private boolean checkBounds(int row, int col) {
        if (row < 1 || row > seats.length) return false;
        if (col < 1 || col > seats[row - 1].length) return false;
        return true;
    }
}
